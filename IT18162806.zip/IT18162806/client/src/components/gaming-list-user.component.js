import React, {Component} from "react";
import {Link} from 'react-router-dom';
import axios from 'axios';
import Card from './cards';
import './games.css';

const Game = props => (
    props.game.name,
    props.game.category,
    props.game.description,
    props.game.rating
)

export default class GamingList extends Component{
    constructor(props) {
        super(props);

        this.state = {games: []};
    }

    componentDidMount() {
        axios.get('http://localhost:5000/gamings/')
            .then(response => {
                this.setState({games: response.data})
            })
            .catch((error) => {
                console.log(error);
            })
    }

    render() {
        return(
            <React.Fragment>
                <div className="products">
                {this.state.games.map((p) => (
                    <Card key={p._id} {...p} />
                ))}
                </div>
            </React.Fragment>
        )
    }
}


