import React, {Component} from "react";
import axios from 'axios';


export default class EditFeedback extends Component{

    constructor(props) {
        super(props);

        this.onChangeName = this.onChangeName.bind(this);
        this.onChangeFeedback = this.onChangeFeedback.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            name: '',
            feedback: '',
        }
    }

    componentDidMount() {
        axios.get('http://localhost:5000/feedback/' +this.props.match.params.id)
            .then(response => {
                this.setState({
                    name: response.data.name,
                    feedback: response.data.feedback,
                })
            })
            .catch((error) => {
                console.log(error);
            })

    }

    onChangeName(e) {
        this.setState({
            name: e.target.value
        });
    }
    
    onChangeFeedback(e) {
        this.setState({
            feedback: e.target.value
        });
    }

    onSubmit(e) {
        e.preventDefault();

        const feedback = {
            name: this.state.name,
            feedback: this.state.feedback,

        };

        console.log(feedback);

        axios.post('http://localhost:5000/feedback/update/'+this.props.match.params.id, feedback)

            .then(res => console.log(res.data));

        alert('Updated Successfully');

        window.location = "/listFeedback";

        this.setState({
            name: '',
            feedback: '',
        })
    }

    render() {
        return (
            <div>
                <h3>Edit Feedback</h3>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label>Name</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.name}
                               onChange={this.onChangeName}
                        />
                    </div>
                   
                    
                    <div className="form-group">
                        <label>Feedback</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.feedback}
                               onChange={this.onChangeFeedback}
                        />
                    </div>

                    <div className="form-group">
                        <input type="submit" value="Update Feedback" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}
