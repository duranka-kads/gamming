import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import axios from 'axios';


export default class Login extends Component {

    constructor(props) {
        super(props);

        this.onChangeName = this.onChangeName.bind(this);
        this.onChangePassword = this.onChangePassword.bind(this);
        
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            username: '',
            password: ''
            
        }
    }

    componentDidMount() {
        axios.get('http://localhost:5000/admin/')
            .then(res => {
                if(res.data.length < 1){
                    const adminObject = {
                        first_name:"John",
                        last_name:"Martin",
                        email:"admin@gmail.com",
                        password:"asdf",
                        access_token:"100"
                    }

                    axios.post('http://localhost:5000/admin/create-admin',adminObject)
                        .then(res => console.log("Admin created"))
                        .catch(err => console.log(err))
                }
            })
            .catch(err => console.log(err))
    }

    onChangeName(e) {
        this.setState({
            username: e.target.value
        });
    }
    onChangePassword(e) {
        this.setState({
            password: e.target.value
        });
    }
    

    onSubmit(e) {
        e.preventDefault();

        const {password} = this.state;
        const email = this.state.username

        axios.get('http://localhost:5000/admin/get-unique-admin/'+email + "/"+password)
        .then(res => {
            if(res.data[0].email === email){
                console.log("Login Success")
                this.props.history.push('/admin')
            }
        })
        .catch(err => console.log("Login failed"))

        this.setState({
            username: '',
            password: ''
            
        })
    }


    render() {
        return (
            <div>
                <h3>Login</h3>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label>Email</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.username}
                               onChange={this.onChangeName}
                        />
                    </div>
                    <div className="form-group">
                        <label>Password</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.password}
                               onChange={this.onChangePassword}
                        />
                    </div>
                    
                  




                    <div className="form-group">
                        <input type="submit" value="Login" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}
