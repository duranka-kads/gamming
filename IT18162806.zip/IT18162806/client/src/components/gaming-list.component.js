import React, {Component} from "react";
import {Link} from 'react-router-dom';
import axios from 'axios';

const Gaming = props => (
    <tr>
        <td>{props.gaming.name}</td>
        <td>{props.gaming.category}</td>
        <td>{props.gaming.description}</td>
        <td>{props.gaming.rating}</td>
        <td>
            <Link to={"/editGaming/"+props.gaming._id}>edit</Link> | <a href="#" onClick={() => { props.deleteGaming(props.gaming._id)}}>delete</a>
        </td>
    </tr>
)

export default class GamingList extends Component{
    constructor(props) {
        super(props);

        this.deleteGaming = this.deleteGaming.bind(this);

        this.state = {gamings: []};
    }

    componentDidMount() {
        axios.get('http://localhost:5000/gamings/')
            .then(response => {
                this.setState({gamings: response.data})
            })
            .catch((error) => {
                console.log(error);
            })
    }

    deleteGaming(id) {
        axios.delete('http://localhost:5000/gamings/'+id)
            .then(res => console.log(res.data));

        this.setState({
            gamings: this.state.gamings.filter(el => el._id !== id)
        })

        alert('Deleted Successfully');
    }

    gamingList() {
        return this.state.gamings.map(currentgaming => {
            return <Gaming gaming = {currentgaming} deleteGaming={this.deleteGaming} key={currentgaming._id}/>
        })
    }

    render() {
        return(
            <div>
                <h3>Games</h3>
                <table className="table">
                    <thead className="thead-light">
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Rate</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        
                    {this.gamingList()}
                    </tbody>
                </table>
            </div>
        )
    }
}
