import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import axios from 'axios';


export default class CreateFeedback extends Component {

    constructor(props) {
        super(props);

        this.onChangeName = this.onChangeName.bind(this);
       
        this.onChangeFeedback = this.onChangeFeedback.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            name: '',
            feedback: '',
        }
    }
    onChangeName(e) {
        this.setState({
            name: e.target.value
        });
    }
    
   
    onChangeFeedback(e) {
        this.setState({
            feedback: e.target.value
        });
    }


    onSubmit(e) {
        e.preventDefault();

        const feedback = {
            name: this.state.name,
            feedback: this.state.feedback,

        };

        console.log(feedback);

        if(this.state.name !== ""){
            axios.post('http://localhost:5000/feedback/add', feedback)

                .then(res => console.log(res.data));

            alert('Successfully Created');

            window.location = "/listFeedback";
        }
        else{
            alert('error 1');
        }



        this.setState({
            name: '',
            feedback: '',
        })
    }


    render() {
        return (
            <div>
                <h3>Create Feedback</h3>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label>Name</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.name}
                               onChange={this.onChangeName}
                        />
                    </div>
                   
                    
                    <div className="form-group">
                        <label>Feedback</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.feedback}
                               onChange={this.onChangeFeedback}
                        />
                    </div>




                    <div className="form-group">
                        <input type="submit" value="Create Feedback" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}
