let mongoose = require('mongoose'),
    express = require('express'),
    router = express.Router();

// User Model
let adminSchema = require('../model/admin.model');

// CREATE User
router.route('/create-admin').post((req, res, next) => {
    adminSchema.create(req.body, (error, data) => {
        if (error) {
            return next(error)
        } else {
            console.log(data)
            res.json(data)
        }
    })
});

//GET All Users
router.route('/').get((req, res) => {
    adminSchema.find((error, data) => {
        if (error) {
            return next(error)
        } else {
            res.json(data)
        }
    })
})

// READ Unique Users
router.route('/get-unique-admin/:email/:password').get((req,res) => {
    adminSchema.find({"email":req.params.email,"password":req.params.password}, (error,data) => {
        if (error) {
            return next(error)
        } else {
            res.json(data);
        }
    })
})

module.exports = router;