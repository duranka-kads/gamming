import React from "react";

//cards in special items
export const card_article = ({
  _id,
  image_path,
  name,
  category,
  description,
  rating

  
}) => {

  return (
    <article className="card">
      <img
        src={`${image_path}`}
        style={{ width: "100%" }}
        alt={`${name}`}
      />
      <div className="card-details">
        <h6>
         Name:{name}
          <br />
          <label>Category:{category}</label>
          <br />
          <label>Description:{description}</label>
          <br />
          <label>Rating:{rating}</label>
        </h6>
        <button className="btn-card">
          <i className="fas fa-shopping-bag"></i> View More
        </button>
      </div>
    </article>
  );
};

export default card_article;