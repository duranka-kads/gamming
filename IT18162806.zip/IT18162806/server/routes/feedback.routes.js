const router = require('express').Router();
let Feedback = require('../model/feedback.model');

router.route('/').get((req,res) =>{
    Feedback.find()
        .then(feedbacks => res.json(feedbacks))
        .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/add').post((req,res) =>{

    const name = req.body.name;
    const feedback = req.body.feedback;

    const newFeedback = new Feedback({
        name,
        feedback
    });

    newFeedback.save()
        .then(() => res.json('Feedback added'))
        .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/:id').get((req,res) => {
    Feedback.findById(req.params.id)
        .then(feedback => res.json(feedback))
        .catch(err => res.status(400).json('Error: ' +err));
});

router.route('/:id').delete((req,res) => {
    Feedback.findByIdAndDelete(req.params.id)
        .then(() => res.json('Feedback Deleted'))
        .catch(err => res.status(400).json('Error: ' +err));
});

router.route('/update/:id').post((req,res) => {
    Feedback.findById(req.params.id)
        .then(feedback => {
            feedback.name = req.body.name;
            feedback.email = req.body.email;
            feedback.phoneNumber = req.body.phoneNumber;
            feedback.feedback = req.body.feedback;


            feedback.save()
                .then(() => res.json('Feedback Updated'))
                .catch(err => res.status(400).json('Error: ' +err));
        })
        .catch(err => res.status(400).json('Error: ' +err));
});


module.exports = router;