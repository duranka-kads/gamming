import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import axios from 'axios';


export default class CreateGaming extends Component {

    constructor(props) {
        super(props);

        this.onChangeName = this.onChangeName.bind(this);
        this.onChangeCategory = this.onChangeCategory.bind(this);
        this.onChangeDescription = this.onChangeDescription.bind(this);
        this.onChangeRate = this.onChangeRate.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            name: '',
            description: '',
            image_path:'',
            category: '',
            rating: '',
        }

      
    }
    onChangeName(e) {
        this.setState({
            name: e.target.value
        });
    }
    onChangeCategory(e) {
        this.setState({
            category: e.target.value
        });
    }
    checkUploadResult = (resultEvent) => {
        if (resultEvent.event === 'success') {
            console.log("Inside checkUploadResult!");
            this.setState({
                image_path: resultEvent.info.secure_url,
                //default_img: this.state.image_path,
            });
            console.log(this.state.image_path);
        }
    }
    showWidget = (widget) => {
        widget.open()
    }
    onChangeDescription(e) {
        this.setState({
            description: e.target.value
        });
    }
    onChangeRate(e) {
        this.setState({
            rating: e.target.value
        });
    }
    onSubmit(e) {
        e.preventDefault();

        const gaming = {
            name: this.state.name,
            category: this.state.category,
            image_path: this.state.image_path,
            description: this.state.description,
            rating: this.state.rating,
        };

        console.log(gaming);

        if(this.state.name !== ""){
            axios.post('http://localhost:5000/gamings/add', gaming)

                .then(res => console.log(res.data));

            alert('Successfully Created');

            window.location = "/listGaming";
        }
        else{
            alert('error 1');
        }



        this.setState({
            name: '',
            category: '',
            image_path: '',
            description: '',
            rating: '',
        })
    }


    render() {
        let widget = window.cloudinary.createUploadWidget({
            cloudName: 'appcomponent',
            uploadPreset: 'duranka',
            sources: [
                "local",
                "url"
            ],
            multiple: false,
            cropping: true,
            resourceType: "image",
            clientAllowedFormats: ["png", "gif", "jpeg"],
            maxImageFileSize: 15000000
        },
            (error, result) => { this.checkUploadResult(result) }
        )
        return (
            <div className="form-group">
                <h3>Create Game</h3>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label>Name</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.name}
                               onChange={this.onChangeName}
                        />

                           


                    </div>

                    <div className="form-group">
                        <label>Description</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.description}
                               onChange={this.onChangeDescription}
                        />
                    </div>

                  

                    <div>
                         <label>Category</label>
                            <select  className="form-control" defaultValue={this.state.category} onChange={this.onChangeCategory}>
                          
                                <option value=" Action games"> Action games</option>
                                <option value="Action-adventure games">Action-adventure games</option>
                                <option value="Role-playing games">Role-playing games</option>
                                <option value="Simulation games">Simulation games</option>
                                <option value="Strategy games">Strategy games</option>
                                <option value="Sports games">Sports games</option>
                                <option value="Puzzle games">Puzzle games</option>
                            </select>
                        </div>

                        <div className="form-group row">
                        <label htmlFor="productImage" className="col-sm-2 col-form-label">Product Image </label>
                        <div className="col-sm-10">
                            <button type="button" onClick={() => this.showWidget(widget)}>Upload Image</button>
                        </div>
                    </div>                 

                         <div>
                         <label>Rating</label>
                            <select  className="form-control" defaultValue={this.state.rating} onChange={this.onChangeRate}>
                          
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>
                   




                    <div className="form-group">
                        <input type="submit" value="SAVE" className="btn btn-primary"  />
                    </div>
                </form>
            </div>
        )
    }
}
