let mongoose = require('mongoose'),
    express = require('express'),
    router = express.Router();

// User Model
let userSchema = require('../model/user.model');

// CREATE User
router.route('/create-user').post((req, res, next) => {
    userSchema.create(req.body, (error, data) => {
        if (error) {
            return next(error)
        } else {
            console.log(data)
            res.json(data)
        }
    })
});

//GET All Users
router.route('/').get((req, res) => {
    userSchema.find((error, data) => {
        if (error) {
            return next(error)
        } else {
            res.json(data)
        }
    })
})

// READ Unique Users
router.route('/get-unique-user/:username/:password').get((req,res) => {
    userSchema.find({"username":req.params.username,"password":req.params.password}, (error,data) => {
        if (error) {
            return next(error)
        } else {
            res.json(data);
        }
    })
})

//Get user by username
router.route('/get-user/:username').get((req,res) => {
    userSchema.find({"username":req.params.username}, (error,data) => {
        if (error) {
            return next(error)
        } else {
            res.json(data);
        }
    })
})

router.route('/add-booking/:id/:hotelID/:startDate/:endDate').put((req,res,next) => {
    userSchema.update({"_id":req.params.id},{
        "$push":{"booking":{"hotelID":req.params.hotelID,"startDate":req.params.startDate,"endDate":req.params.endDate}}
    },(error,data)=> {
        if(error) {
            return next(error);
        } else {
            res.json(data);
            console.log("Successfully added to shopping cart");
        }
    })
})

router.route('/delete-booking/:_id/:hotelID').put((req,res,next) => {
    userSchema.update({"_id":req.params._id},{
        "$pull":{"booking":{"hotelID":req.params.hotelID}}
    },(error,data)=> {
        if(error) {
            return next(error);
        } else {
            res.json(data);
            console.log("Successfully deleted");
        }
    })
})

router.route('/get-unique-user/:id').get((req,res,next) => {
    userSchema.find({"_id":req.params.id}, (error,data) => {
        if (error) {
            return next(error)
        } else {
            res.json(data);
        }
    })
})

module.exports = router;