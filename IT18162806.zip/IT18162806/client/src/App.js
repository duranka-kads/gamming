import React from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route} from "react-router-dom";

import Navbar from "./components/navbar.component"
import CreateGaming from "./components/create-gaming.component";
import GamingList from "./components/gaming-list.component";
import EditGaming from "./components/edit-gaming.component";
import MainComponent from "./components/main.component";


import CreateFeedback from "./components/create-feedback.component";
import FeedbackList from "./components/feedback-list.component";
import EditFeedback from "./components/edit-feedback.component";

import GamingListUser from "./components/gaming-list-user.component.js";

import AdminDashboard from "./components/adminDashbord.component";

import Login from "./components/login.component";



function App() {
  return (
      <Router>
        <div className="container">
            <Navbar />
            <Route path="/createGaming" exact component={CreateGaming} />
            <Route path="/listGaming" exact component={GamingList} />
            <Route path="/editGaming/:id" exact component={EditGaming} />

            <Route path="/" exact component={MainComponent} />

            <Route path="/createFeedback" exact component={CreateFeedback} />
            <Route path="/listFeedback" exact component={FeedbackList} />
            <Route path="/editFeedback/:id" exact component={EditFeedback} />

            <Route path="/listGamingUser" exact component={GamingListUser} />
            

            <Route path="/admin" exact component={AdminDashboard} />
            <Route path="/login" exact component={Login} />
            
            <br />


        </div>
      </Router>
  );
}

export default App;