const router = require('express').Router();
let Gaming = require('../model/game.model');

router.route('/').get((req,res) =>{
    Gaming.find()
        .then(gamings => res.json(gamings))
        .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/add').post((req,res) =>{

    const name = req.body.name;
    const description = req.body.description;
    const image_path = req.body.image_path;
    const category = req.body.category;
    const rating = req.body.rating;


    const newGaming = new Gaming({
        name,
        description,
        image_path,
        category,
        rating
    });

    newGaming.save()
        .then(() => res.json('Game added'))
        .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/:id').get((req,res) => {
    Gaming.findById(req.params.id)
        .then(gaming => res.json(gaming))
        .catch(err => res.status(400).json('Error: ' +err));
});

router.route('/:id').delete((req,res) => {
    Gaming.findByIdAndDelete(req.params.id)
        .then(() => res.json('Game Deleted'))
        .catch(err => res.status(400).json('Error: ' +err));
});

router.route('/update/:id').post((req,res) => {
    Gaming.findById(req.params.id)
        .then(gaming => {
            gaming.name = req.body.name;
            gaming.category = req.body.category;
            gaming.description = req.body.description;
            gaming.rate = req.body.rate;


            gaming.save()
                .then(() => res.json('Game Updated'))
                .catch(err => res.status(400).json('Error: ' +err));
        })
        .catch(err => res.status(400).json('Error: ' +err));
});


module.exports = router;