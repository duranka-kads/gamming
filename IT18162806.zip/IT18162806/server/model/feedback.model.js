const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const feedbackSchema = new Schema({
    name: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        minlength: 3
    },
  
    
    feedback: {
        type: String,
        required: true,
    },


}, {
    timestamp: true,
});

const Feedback = mongoose.model('Feedback', feedbackSchema);

module.exports = Feedback;