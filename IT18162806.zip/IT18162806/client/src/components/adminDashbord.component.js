import React, {Component} from 'react';
import {Link} from 'react-router-dom';

export default class AdminDashboard extends Component {
    render() {
        return (
            <div>
                <center>

                    <h3>Admin Dashboard</h3><br/><br/>

                    <Link to="/createGaming">

                        <button className="btn btn-primary btn-lg" >Add New Game</button>

                    </Link><br/><br/><br/>

                    <Link to="/listGaming">

                        <button className="btn btn-primary btn-lg " >View All Games</button>

                    </Link><br/><br/><br/>

                    <Link to="/listFeedback">

                        <button className="btn btn-primary btn-lg">View All Feedbacks</button>

                    </Link>

                </center>

            </div>
        )
    }
}
