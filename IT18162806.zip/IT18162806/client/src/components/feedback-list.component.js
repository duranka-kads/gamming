import React, {Component} from "react";
import {Link} from 'react-router-dom';
import axios from 'axios';

const Feedback = props => (
    <tr>
        <td>{props.feedback.name}</td>
        <td>{props.feedback.feedback}</td>
        <td>
            <Link to={"/editFeedback/"+props.feedback._id}>edit</Link> | <a href="#" onClick={() => { props.deleteFeedback(props.feedback._id)}}>delete</a>| <Link to={"/admin"}>Move Back</Link>
        </td>
    </tr>
)

export default class FeedbackList extends Component{
    constructor(props) {
        super(props);

        this.deleteFeedback = this.deleteFeedback.bind(this);

        this.state = {feedbacks: []};
    }

    componentDidMount() {
        axios.get('http://localhost:5000/feedback/')
            .then(response => {
                this.setState({feedbacks: response.data})
            })
            .catch((error) => {
                console.log(error);
            })
    }

    deleteFeedback(id) {
        axios.delete('http://localhost:5000/feedback/'+id)
            .then(res => console.log(res.data));

        this.setState({
            feedbacks: this.state.feedbacks.filter(el => el._id !== id)
        })

        alert('Deleted Successfully');
    }

    feedbackList() {
        return this.state.feedbacks.map(currentfeedback => {
            return <Feedback feedback = {currentfeedback} deleteFeedback={this.deleteFeedback} key={currentfeedback._id}/>
        })
    }

    render() {
        return(
            <div>
                <h3>Feedbacks</h3>
                <table className="table">
                    <thead className="thead-light">
                    <tr>
                        <th>Name</th>
                        <th>Feedback</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    {this.feedbackList()}
                    </tbody>
                </table>
            </div>
        )
    }
}
