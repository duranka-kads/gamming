import React, {Component} from 'react';
import {Link} from 'react-router-dom';

export default class MainComponent extends Component {
    render() {
        return (
            <div>

<h2 style={{textAlign:"center"}}> Welcome to the Gaming site</h2>
               
  <img  src = "https://cdn.mos.cms.futurecdn.net/XNkFV6uyYBeX5NLwjnomig-650-80.jpg.webp" height="400" width="1100"/>

                <h5 style={{textAlign:"center"}}> Sell! Nobody is really interested in a description of your game. People are there because they want you to persuade them to buy / play it. Use the opportunity to sell your game directly to the player.
Avoid “[title] is a…” in your description. It’s boring and is more suited to an encyclopaedia than a sales pitch for a game.
Be sparing with techie and gamer words. They probably don’t mean as much to the reader as they do to you, and they carry no emotion for most people. MMO, RPG, persistent browser game — these words don’t mean much to most people, and will rarely close a sale.
Do use “genre appropriate” words. Action games should include words like “action-packed”, “fast-paced”, “thrilling”. Hidden Object Games should include words like “discover”, “find”, “uncover”, “unlock”, “mysteries”. And so on.
Every single thing you say must be a good reason to play. If you’ve put in a sentence or phrase that doesn’t give the player a reason to play, take it out.
Start sentences with VERBS. Starting sentences with a verb puts the player into the action. “Fight your way to the top!” is better than, “A game where you must fight your way to the top” — and much better than “get to the top by fighting”. Serve up big, action packed verbs at the start of sentences.</h5>
            </div>
        )
    }
}
