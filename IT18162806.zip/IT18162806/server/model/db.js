const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://admin:123@gameapp-jusbm.mongodb.net/test', { useNewUrlparser:true }, (err) =>{
    if(!err) { console.log('Mongodb connection succeeded.')}
    else {console.log('error connection' + err)}
});

require('./game.model');