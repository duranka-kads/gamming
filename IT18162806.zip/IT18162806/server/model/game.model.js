const  mongoose = require('mongoose');
const Schema = mongoose.Schema

let Ratings = new Schema({
    comment: {
        type: String
    },
    value: {
        type: Number,
        required: true
    },
    user_id: {
        type: mongoose.Types.ObjectId,
        required: true
    },
    date: {
        type: Date,
        default: Date.now
    },
});

let Game = new Schema({
    name: {
        type: String
    },
    description: {
        type: String
    },
    image_path: {
        type: String
    },
    category: {
        type: Object
    },
    rating: {
        type: Object
    }
});

module.exports = mongoose.model('Game', Game), mongoose.model('Rating', Ratings)