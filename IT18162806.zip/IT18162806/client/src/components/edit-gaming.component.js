import React, {Component} from "react";
import axios from 'axios';


export default class EditGaming extends Component{

    constructor(props) {
        super(props);

        this.onChangeName = this.onChangeName.bind(this);
        this.onChangeCategory = this.onChangeCategory.bind(this);
        this.onChangeDescription = this.onChangeDescription.bind(this);
        this.onChangeRate = this.onChangeRate.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            name: '',
            category: '',
            description: '',
            rate: '',
        }
    }

    componentDidMount() {
        axios.get('http://localhost:5000/gamings/' +this.props.match.params.id)
            .then(response => {
                this.setState({
                    name: response.data.name,
                    category: response.data.category,
                    description: response.data.description,
                    rate: response.data.rate,
                })
            })
            .catch((error) => {
                console.log(error);
            })

    }

    onChangeName(e) {
        this.setState({
            name: e.target.value
        });
    }
    onChangeCategory(e) {
        this.setState({
            category: e.target.value
        });
    }
    onChangeDescription(e) {
        this.setState({
            description: e.target.value
        });
    }
    onChangeRate(e) {
        this.setState({
            rate: e.target.value
        });
    }

    onSubmit(e) {
        e.preventDefault();

        const gaming = {
            name: this.state.name,
            category: this.state.category,
            description: this.state.description,
            rate: this.state.rate,

        };

        console.log(gaming);

        axios.post('http://localhost:5000/gamings/update/'+this.props.match.params.id, gaming)

            .then(res => console.log(res.data));

        alert('Updated Successfully');

        window.location = "/listGaming";

        this.setState({
            name: '',
            category: '',
            description: '',
            rate: '',
        })
    }

    render() {
        return (
            <div>
                <h3>Edit Booking</h3>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label>Name</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.name}
                               onChange={this.onChangeName}
                        />
                    </div>
                    <div>
                         <label>Category</label>
                            <select  className="form-control" value={this.state.category} onChange={this.onChangeCategory}>
                          
                                <option value=" Action games"> Action games</option>
                                <option value="Action-adventure games">Action-adventure games</option>
                                <option value="Role-playing games">Role-playing games</option>
                                <option value="Simulation games">Simulation games</option>
                                <option value="Strategy games">Strategy games</option>
                                <option value="Sports games">Sports games</option>
                                <option value="Puzzle games">Puzzle games</option>
                            </select>
                        </div>
                    <div className="form-group">
                        <label>Description</label>
                        <input type="text"
                               required
                               className="form-control"
                               value={this.state.description}
                               onChange={this.onChangeDescription}
                        />
                    </div>
                    <div>
                         <label>Rating</label>
                            <select  className="form-control" defaultValue={this.state.rating} onChange={this.onChangeRate}>
                          
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>

                    <div className="form-group">
                        <input type="submit" value="Update Booking" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}
